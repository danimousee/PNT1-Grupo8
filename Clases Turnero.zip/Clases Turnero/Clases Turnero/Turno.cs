﻿using System;

public class Turno
{
	public int nroComprobante;
	public DateTime diaHora;
	public Actividad actividad;
	public Cuenta idPersona;


}

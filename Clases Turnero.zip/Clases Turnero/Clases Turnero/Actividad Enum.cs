﻿using System;

public enum Actividad
{
	Yoga,
	Pilates,
	Natacion,
	TaiChi
}

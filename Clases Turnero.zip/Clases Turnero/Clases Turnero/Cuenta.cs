﻿using System;
using System.Collections.Generic;

public class Cuenta
{
	public String direccionCorreo;
	public String contraseña;
	public String codVerif;
	public String nombreCompleto;
	public int edad;
	public int dni;
	public List<Turno> turnosReservados;


}

﻿using System;

namespace Clases_Turnero
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
